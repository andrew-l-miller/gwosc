AGGIORN 2018:

downlaod from http://lappweb.in2p3.fr/virgo/FrameL/
July 2018: v8r26
unzip.
go under mgr and,
On a Linux machine (possible on fifferent OS), ./
Creates libFrame.a in the directory Linux-x86_64

==> Copy under framelib2018 (sostituisce framelib di prima), with the needed .h (they are under src)
Faccio compila2018 che usa questo folder per compilare !!!

======


To update FrameUtil to a new FrameLib version


1. Download the latest FrameLib package (e.g. v8r04.tar.gz)

2. gunzip v8r04.tar.gz; tar -xvf v8r04.tar

3. cd v8r04; cd mgr

4. makegcc 
	-> Vengono create, nella dir. Linux-x86, la nuova libreria statica libFrame.a e dinamica libFrame.so

5. Copy the static library and the .h files contained in /src in the directory framelib 
   (parallel to pss):  
	libFrame.a
	FrameL.h  
	FrFilter.h  
	FrIO.h  
	FrSegListTool.h  
	FrVect.h

6. Go in /pss/FrameUtil and execute the compilation/linking commands in FrameUtil_makefile.txt:
	rm -f  *.o
 	gcc -g -Wall -W -c ../pss_lib/pss_gw.c
 	gcc -g -Wall -W -c ../pss_lib/pss_math.c
 	gcc -g -Wall -W -c ../pss_lib/pss_serv.c
 	gcc -g -Wall -W -c ../pss_lib/pss_snag.c
 	gcc -g -Wall -W -c ../pss_lib/pss_sfc.c
 	gcc -g -Wall -I../../framelib -W -c ../pss_lib/pss_frame.c
 	gcc -g -Wall  -I../pss_lib/ -I../../framelib -W -c frame_util.c

 	gcc -g -Wall -W -o FrameUtilMain frame_util.o FrameUtilMain.c pss_gw.o pss_math.o 
	pss_serv.o pss_snag.o  pss_sfc.o pss_frame.o  -lm ../../framelib/libFrame.a
PS. On some machines the -I option seems not work: replace with "-iquote".

7. The new executable FrameUtilMain is created.

